# TSP 监测盒调试神器 —— Android 手机版

PC 版（Python + Tkinter）完整移植到 Android，支持通过 **USB OTG + USB 转串口线（CH340 / CP210x / FTDI / PL2303 / CH9102 等）** 连接真实粉尘监测设备，或模拟设备应答调试。

## 功能（与 PC 版 v7.9 完全对应）

| 功能 | PC 版 | Android 版 |
|---|---|---|
| 主站模式：发送读取指令、单次/循环读取 | main.py `send_single_read` / `toggle_reading` | MainActivity 同逻辑 |
| 解析 0x3A 协议帧 → TSP/PM10/PM2.5 | main.py `on_frame` | MainActivity `onFrame` |
| 从站模式：匹配指令自动应答 | main.py simulate 分支 | MainActivity `onFrame` simulate 分支 |
| 随机模拟数据（含天气模式比例、80% 平滑漂移） | `generate_random` | `generateRandom` |
| 36 字节报文数据区实时 HEX | `update_raw_hex` | `buildPayload` / `updateRawHex` |
| 平滑趋势图（3 条曲线） | matplotlib + scipy 样条 | LineChartView + Catmull-Rom 样条 |
| 粘包/半包帧切割 | protocol.py `FrameBuffer` | Protocol.kt `FrameBuffer` |
| CRC16-Modbus 校验 | protocol.py `crc16_modbus` | Protocol.kt `crc16Modbus` |
| 串口读写线程 | serial_worker.py | SerialManager（UsbSerial 库） |

## 使用说明

1. **安装**：将 `TSPTester-v7.9-Android.apk` 传到手机（微信/QQ/网盘均可），点击安装。
   - 需允许"安装未知来源应用"。
   - 支持 Android 7.0（API 24）及以上。
2. **连接硬件**：手机通过 OTG 转接线接 USB 转串口模块（CH340/CP210x 等），再接监测盒的串口（TTL 电平注意接线方向）。
   - 插上设备后打开 App，点"刷新"，在下拉框选中串口设备。
   - 首次使用会弹出 USB 权限授权框，点允许。
3. **波特率**：默认 19200（与 PC 版一致），可选 9600 / 19200 / 38400 / 57600 / 115200。
4. **主站模式**：打开串口 → 发送一次测试 或 开始循环读取 → 观察实时数据、趋势图与报文区。
5. **从站模式**：勾选"启用自动应答"，可勾选"每次随机"并设置 TSP 范围；也可手动修改 PM2.5/PM10/TSP 数值生成自定义报文。
6. **读取指令**：主站模式锁定（与 PC 版一致），从站模式可编辑（匹配指令才应答）。

## 构建（源码方式）

```bash
# 需要 JDK 17 + Android SDK（platform 33, build-tools 33.0.2）+ Gradle 7.5
cd TSPTester-Android
JAVA_HOME=<jdk17> ANDROID_HOME=<sdk> gradle assembleDebug
# 产物: app/build/outputs/apk/debug/app-debug.apk
```

工程结构：

```
TSPTester-Android/
├── settings.gradle.kts / build.gradle.kts / gradle.properties
└── app/
    ├── build.gradle.kts
    └── src/main/
        ├── AndroidManifest.xml          # USB Host 权限、设备插拔监听
        ├── java/com/tsp/tester/
        │   ├── MainActivity.kt          # 全部业务逻辑（对应 main.py）
        │   ├── protocol/Protocol.kt     # 协议层（对应 protocol.py / config.py）
        │   ├── serial/SerialManager.kt  # 串口层（对应 serial_worker.py）
        │   └── ui/LineChartView.kt      # 趋势图控件（对应 matplotlib 图表）
        └── res/                         # 布局 / 主题 / 图标 / device_filter
```

## 已知差异

- 图表悬停查看数值（PC 版鼠标 hover）在手机上改为图例区实时显示最后值。
- USB 串口芯片兼容性取决于手机 OTG 与驱动库（usb-serial-for-android，支持主流国产芯片）。
