@echo off
setlocal
rem ============================================
rem  TSPTester one-click APK build (local env)
rem  JDK17 + Gradle7.5 + Aliyun mirrors
rem ============================================

set "JAVA_HOME=C:\Users\Admin\Doubao\chats\2026-11-02\new-chat\build-env\jdk-17.0.2"
set "GRADLE_HOME=C:\Users\Admin\Doubao\chats\2026-11-02\new-chat\build-env\gradle-7.5"
set "ANDROID_HOME=C:\Users\Admin\AppData\Local\Android\Sdk"
set "ANDROID_SDK_ROOT=C:\Users\Admin\AppData\Local\Android\Sdk"
set "PATH=C:\Windows\System32;C:\Windows;%JAVA_HOME%\bin;%PATH%"

cd /d "%~dp0"

echo.
echo ============================================
echo   TSPTester - building debug APK ...
echo ============================================
echo.

call "%GRADLE_HOME%\bin\gradle.bat" assembleDebug --no-daemon --console=plain

if %ERRORLEVEL%==0 (
    echo.
    echo ============================================
    echo   BUILD OK!
    echo   APK: app\build\outputs\apk\debug\app-debug.apk
    echo ============================================
    explorer "app\build\outputs\apk\debug"
) else (
    echo.
    echo ============================================
    echo   BUILD FAILED. Check messages above.
    echo ============================================
)
pause
