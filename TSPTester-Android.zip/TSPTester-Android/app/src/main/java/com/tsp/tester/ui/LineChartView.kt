package com.tsp.tester.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View
import kotlin.math.max
import kotlin.math.min

/**
 * 历史数据趋势图 —— 对应 PC 版 matplotlib 图表 + scipy 样条平滑。
 * 用 Catmull-Rom 样条替代 make_interp_spline 实现平滑曲线。
 */
class LineChartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0,
) : View(context, attrs, defStyleAttr) {

    data class Point(val time: String, val tsp: Float, val pm10: Float, val pm25: Float)

    private val maxPoints = 100
    private val points = ArrayDeque<Point>()

    // 颜色与 PC 版一致
    private val tspColor = Color.rgb(0xFF, 0x4D, 0x4F)
    private val pm10Color = Color.rgb(0xFF, 0xA9, 0x40)
    private val pm25Color = Color.rgb(0x18, 0x90, 0xFF)
    private val gridColor = Color.rgb(0xCC, 0xCC, 0xCC)
    private val axisColor = Color.rgb(0x88, 0x88, 0x88)
    private val textColor = Color.rgb(0x55, 0x55, 0x55)
    private val bgColor = Color.WHITE

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(1.4f)
        strokeCap = Paint.Cap.ROUND
    }
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(0.6f)
        color = gridColor
    }
    private val axisPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(1f)
        color = axisColor
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = textColor
        textSize = dp(9f)
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = textColor
        textSize = dp(10f)
    }

    fun addPoint(time: String, tsp: Float, pm10: Float, pm25: Float) {
        points.addLast(Point(time, tsp, pm10, pm25))
        while (points.size > maxPoints) points.removeFirst()
        invalidate()
    }

    fun clear() {
        points.clear()
        invalidate()
    }

    fun isEmpty(): Boolean = points.isEmpty()

    private fun dp(v: Float): Float = v * resources.displayMetrics.density

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(bgColor)

        val padL = dp(10f)
        val padR = dp(10f)
        val padT = dp(28f)
        val padB = dp(22f)
        val chartW = width - padL - padR
        val chartH = height - padT - padB

        if (chartW <= 0 || chartH <= 0) return

        // ---- 图例（左上角，带最后值）----
        drawLegend(canvas)

        if (points.isEmpty()) {
            textPaint.color = textColor
            canvas.drawText("等待数据…", width / 2f - dp(30f), height / 2f, textPaint)
            return
        }

        // ---- 量程 ----
        val maxVal = max(
            points.maxOf { max(it.tsp, max(it.pm10, it.pm25)) },
            10f
        ) * 1.2f
        val minVal = 0f

        val x0 = padL
        val x1 = padL + chartW
        val y0 = padT
        val y1 = padT + chartH

        fun mapX(i: Int): Float = x0 + (i.toFloat() / max(points.size - 1, 1)) * chartW
        fun mapY(v: Float): Float = y1 - ((v - minVal) / (maxVal - minVal)) * chartH

        // ---- 网格 + Y 轴刻度 ----
        val gridLines = 5
        for (g in 0..gridLines) {
            val frac = g.toFloat() / gridLines
            val gy = y0 + frac * chartH
            gridPaint.color = gridColor
            canvas.drawLine(x0, gy, x1, gy, gridPaint)
            val label = ((maxVal - minVal) * (1f - frac) + minVal).toInt()
            textPaint.color = textColor
            canvas.drawText(label.toString(), x0 - dp(2f) - textPaint.measureText(label.toString()), gy + dp(3f), textPaint)
        }

        // X 轴与 Y 轴
        canvas.drawLine(x0, y1, x1, y1, axisPaint)
        canvas.drawLine(x0, y0, x0, y1, axisPaint)

        // ---- X 轴时间标签（最多 4 个）----
        val n = points.size
        val idxSet = listOf(0, n / 3, n * 2 / 3, n - 1).distinct().filter { it in 0 until n }
        textPaint.color = textColor
        for (i in idxSet) {
            val label = points.elementAt(i).time
            val lx = mapX(i)
            val half = textPaint.measureText(label) / 2f
            canvas.drawText(label, (lx - half).coerceIn(x0, x1 - textPaint.measureText(label)), y1 + dp(13f), textPaint)
        }

        // ---- 三条曲线（Catmull-Rom 样条平滑）----
        val xs = (0 until n).map { mapX(it).toFloat() }
        drawSmoothLine(canvas, xs, points.map { mapY(it.tsp) }, tspColor)
        drawSmoothLine(canvas, xs, points.map { mapY(it.pm10) }, pm10Color)
        drawSmoothLine(canvas, xs, points.map { mapY(it.pm25) }, pm25Color)
    }

    private fun drawLegend(canvas: Canvas) {
        val x = dp(10f)
        val y = dp(16f)
        var cx = x
        val last = points.lastOrNull()
        fun legendItem(color: Int, name: String, value: Float?) {
            val swatch = dp(8f)
            labelPaint.color = color
            canvas.drawRect(cx, y - swatch, cx + swatch, y, labelPaint)
            labelPaint.color = textColor
            val text = "$name: ${value?.toInt() ?: 0}"
            canvas.drawText(text, cx + swatch + dp(4f), y + dp(1f), labelPaint)
            cx += swatch + dp(4f) + labelPaint.measureText(text) + dp(12f)
        }
        legendItem(tspColor, "TSP", last?.tsp)
        legendItem(pm10Color, "PM10", last?.pm10)
        legendItem(pm25Color, "PM2.5", last?.pm25)
    }

    private fun drawSmoothLine(canvas: Canvas, xs: List<Float>, ys: List<Float>, color: Int) {
        if (ys.size < 2) return
        linePaint.color = color
        val path = Path()
        path.moveTo(xs[0], ys[0])
        for (i in 0 until xs.size - 1) {
            val p0 = max(i - 1, 0)
            val p1 = i
            val p2 = i + 1
            val p3 = min(i + 2, xs.size - 1)
            for (t in 1..12) {
                val u = t / 12f
                path.lineTo(
                    catmullRom(xs[p0], xs[p1], xs[p2], xs[p3], u),
                    catmullRom(ys[p0], ys[p1], ys[p2], ys[p3], u),
                )
            }
        }
        canvas.drawPath(path, linePaint)
    }

    private fun catmullRom(p0: Float, p1: Float, p2: Float, p3: Float, t: Float): Float {
        val t2 = t * t
        val t3 = t2 * t
        return 0.5f * (
            2f * p1 +
                (-p0 + p2) * t +
                (2f * p0 - 5f * p1 + 4f * p2 - p3) * t2 +
                (-p0 + 3f * p1 - 3f * p2 + p3) * t3
            )
    }
}
