package com.tsp.tester

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.tsp.tester.databinding.ActivityMainBinding
import com.tsp.tester.protocol.FrameBuffer
import com.tsp.tester.protocol.Protocol
import com.tsp.tester.serial.SerialManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Random
import kotlin.math.max
import kotlin.math.min

/**
 * TSP 监测盒调试神器 —— Android 移植版。
 * 对应 PC 版 main.py 的全部功能：
 *   - 主站模式：读取真实设备，解析 0x3A 协议帧，显示 TSP/PM10/PM2.5 与趋势图
 *   - 从站模式：模拟设备，匹配指令后自动应答（含随机数据）
 */
class MainActivity : AppCompatActivity() {

    companion object {
        const val USB_PERMISSION = "com.tsp.tester.USB_PERMISSION"
        const val MAX_LOG_LINES = 500
    }

    private lateinit var binding: ActivityMainBinding
    private lateinit var serial: SerialManager

    private val fb = FrameBuffer()
    private val handler = Handler(Looper.getMainLooper())
    private val random = Random()

    // 串口接收缓冲（对应 main.py rx_raw_buffer，100ms 合并输出日志）
    private val rxRawBuffer = ArrayList<Byte>()
    private var rxFlushRunnable: Runnable? = null

    // 循环读取（对应 main.py read_job）
    private var isReading = false
    private var readLoopRunnable: Runnable? = null

    // 模拟数据记忆（对应 main.py last_tsp 等）
    private var lastTsp: Int? = null
    private var lastPm10: Int? = null
    private var lastPm25: Int? = null

    private val baudOptions = listOf("9600", "19200", "38400", "57600", "115200")
    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                USB_PERMISSION -> {
                    val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                    val device = getUsbDevice(intent)
                    if (granted && device != null) {
                        openSerial(device)
                    } else {
                        toast("USB 权限被拒绝")
                    }
                }
                UsbManager.ACTION_USB_DEVICE_DETACHED -> {
                    val device = getUsbDevice(intent)
                    if (serial.isOpen() && device != null && device == serial.currentDevice()) {
                        if (isReading) stopLoop()
                        serial.close()
                        updateSerialUi(false)
                        log("❌ USB 设备已拔出")
                    }
                    refreshDevices()
                }
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun getUsbDevice(intent: Intent): UsbDevice? =
        if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
        } else {
            intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        serial = SerialManager(this)
        // 注册串口数据回调：读线程收到数据 → 主线程处理
        // （此前缺失该注册，RX 数据被直接丢弃，导致"读取不到串口数据"）
        serial.onData = { data -> handler.post { processRx(data) } }
        serial.onError = { msg -> handler.post { log("❌ 串口错误: $msg") } }

        setupBaudSpinner()
        setupModeToggle()
        setupButtons()
        setupValueEditors()

        binding.toggleGroupMode.check(binding.radioRead.id)
        refreshDevices()
    }

    // ==================== UI 初始化 ====================

    private fun setupBaudSpinner() {
        binding.spinnerBaud.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, baudOptions
        )
        binding.spinnerBaud.setSelection(1) // 默认 19200，与 PC 版一致
    }

    // 当前是否主站模式（权威状态：以正在被勾选的按钮 id 为准。
    // 关键修复：MaterialButtonToggleGroup 单选切换时"先勾新、后取消旧"，
    // 若按 radioSim.isChecked 判断，切主站瞬间旧按钮仍未取消 → 误判为从站 → 面板切不过去）
    private var modeIsRead = true

    private fun setupModeToggle() {
        binding.toggleGroupMode.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (isChecked) {
                modeIsRead = checkedId == binding.radioRead.id
                onModeChange()
            }
        }
    }

    private fun setupButtons() {
        binding.btnRefresh.setOnClickListener { refreshDevices() }
        binding.btnSerial.setOnClickListener { toggleSerial() }
        binding.btnSendOnce.setOnClickListener { sendSingleRead() }
        binding.btnLoop.setOnClickListener { toggleReading() }
        binding.btnRandom.setOnClickListener { generateRandom() }
        binding.btnClearLog.setOnClickListener { binding.txtLog.text = "" }
        binding.chkAutoRandom.setOnCheckedChangeListener { _, _ -> onRandomToggle() }
    }

    private fun setupValueEditors() {
        val watcher = object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                if (modeIsSimulate() && !binding.chkAutoRandom.isChecked) updateRawHex()
            }
        }
        binding.edtPm25.addTextChangedListener(watcher)
        binding.edtPm10.addTextChangedListener(watcher)
        binding.edtTsp.addTextChangedListener(watcher)
    }

    private fun modeIsSimulate(): Boolean = !modeIsRead

    // ==================== 模式切换（对应 main.py on_mode_change） ====================

    private fun onModeChange() {
        clearChart()
        setValues("0", "0", "0")
        val isRead = !modeIsSimulate()
        binding.readPanel.visibility = if (isRead) View.VISIBLE else View.GONE
        binding.simPanel.visibility = if (isRead) View.GONE else View.VISIBLE

        if (isRead) {
            binding.chkAutoReply.isChecked = false
            setValueEditable(false)
            binding.txtReadCmd.isEnabled = false
            log("--- 已切换至主站模式 (读取指令已锁定) ---")
        } else {
            if (isReading) stopLoop()
            onRandomToggle()
            binding.txtReadCmd.isEnabled = true
            log("--- 已切换至从站模式 (需完全匹配指令才回复) ---")
        }
        updateRawHex()
    }

    private fun onRandomToggle() {
        if (modeIsSimulate() && binding.chkAutoRandom.isChecked) {
            setValueEditable(false)
        } else if (modeIsSimulate()) {
            setValueEditable(true)
        } else {
            setValueEditable(false)
        }
    }

    private fun setValueEditable(editable: Boolean) {
        listOf(binding.edtPm25, binding.edtPm10, binding.edtTsp).forEach {
            it.isFocusable = editable
            it.isFocusableInTouchMode = editable
            it.isClickable = editable
        }
    }

    private fun setValues(pm25: String, pm10: String, tsp: String) {
        binding.edtPm25.setText(pm25)
        binding.edtPm10.setText(pm10)
        binding.edtTsp.setText(tsp)
    }

    // ==================== 串口 ====================

    private fun refreshDevices() {
        val devices = serial.listDevices()
        val names = devices.map { describeDevice(it) }
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        binding.spinnerDevice.adapter = adapter
        if (names.isEmpty()) {
            val all = serial.listAllUsbDevices()
            if (all.isEmpty()) {
                log("ℹ 未检测到任何 USB 设备，请确认 OTG 线支持数据传输")
            } else {
                val desc = all.joinToString(", ") {
                    String.format(Locale.US, "0x%04X:0x%04X", it.vendorId, it.productId)
                }
                log("ℹ 有 ${all.size} 个 USB 设备但未识别为串口 (VID:PID=$desc)，可能芯片驱动不支持")
            }
        } else {
            log("ℹ 检测到 ${names.size} 个串口设备")
        }
    }

    private fun describeDevice(d: UsbDevice): String {
        val name = d.productName ?: d.deviceName
        return String.format(Locale.US, "%s (0x%04X:0x%04X)", name, d.vendorId, d.productId)
    }

    private fun selectedDevice(): UsbDevice? {
        val idx = binding.spinnerDevice.selectedItemPosition
        return serial.listDevices().getOrNull(idx)
    }

    private fun toggleSerial() {
        if (serial.isOpen()) {
            if (isReading) stopLoop()
            serial.close()
            updateSerialUi(false)
            log("❌ 串口已关闭")
            return
        }
        val device = selectedDevice()
        if (device == null) {
            toast("未找到串口设备，请先连接 USB 转串口")
            return
        }
        if (!serial.hasPermission(device)) {
            serial.requestPermission(
                device,
                PendingIntent.getBroadcast(
                    this, 0, Intent(USB_PERMISSION), PendingIntent.FLAG_IMMUTABLE
                )
            )
            return
        }
        openSerial(device)
    }

    private fun openSerial(device: UsbDevice) {
        val baud = binding.spinnerBaud.selectedItem?.toString()?.toIntOrNull() ?: 19200
        try {
            serial.open(device, baud)
            updateSerialUi(true)
            log("✅ 串口已打开: ${describeDevice(device)} @ $baud")
            toast("串口已连接")
        } catch (e: Exception) {
            toast("串口错误: ${e.message}")
            log("❌ 串口错误: ${e.message}")
        }
    }

    private fun updateSerialUi(open: Boolean) {
        binding.btnSerial.text = if (open) getString(R.string.close) else getString(R.string.open)
        binding.txtStatus.text = if (open) "已连接" else "未连接"
        binding.txtStatus.setTextColor(
            if (open) getColor(R.color.ok_green) else getColor(R.color.text_sub)
        )
    }

    // ==================== 主站读取（对应 main.py send_single_read / toggle_reading） ====================

    private fun sendSingleRead() {
        if (!serial.isOpen()) {
            toast("请先打开串口")
            return
        }
        val cmd = parseCmd()
        if (cmd != null) {
            serial.send(cmd)
            log("📡 TX(主站单次) → ${Protocol.toHex(cmd)}")
        } else {
            log("❌ 读取指令 HEX 格式错误！")
        }
    }

    private fun toggleReading() {
        if (!serial.isOpen()) {
            toast("请先打开串口")
            return
        }
        if (isReading) {
            stopLoop()
            log("⏹ 停止循环读取")
        } else {
            isReading = true
            binding.btnLoop.text = getString(R.string.loop_stop)
            log("▶ 开始循环读取")
            doReadLoop()
        }
    }

    private fun stopLoop() {
        isReading = false
        binding.btnLoop.text = getString(R.string.loop_start)
        readLoopRunnable?.let { handler.removeCallbacks(it) }
        readLoopRunnable = null
    }

    private fun doReadLoop() {
        if (!isReading) return
        if (!serial.isOpen()) {
            stopLoop()
            return
        }
        val cmd = parseCmd()
        if (cmd != null) {
            serial.send(cmd)
            log("📡 TX(主站循环) → ${Protocol.toHex(cmd)}")
        } else {
            log("❌ 读取指令 HEX 格式错误，停止循环")
            stopLoop()
            return
        }
        val interval = binding.edtInterval.text.toString().toIntOrNull() ?: 1000
        readLoopRunnable = Runnable { doReadLoop() }
        handler.postDelayed(readLoopRunnable!!, interval.toLong())
    }

    private fun parseCmd(): ByteArray? {
        val hex = binding.txtReadCmd.text.toString()
            .filter { it.isDigit() || it.lowercaseChar() in 'a'..'f' }
        return try {
            if (hex.length % 2 != 0) null else ByteArray(hex.length / 2) {
                hex.substring(it * 2, it * 2 + 2).toInt(16).toByte()
            }
        } catch (e: Exception) {
            null
        }
    }

    // ==================== 从站模拟（对应 main.py generate_random / build_sim_frame） ====================

    private fun generateRandom() {
        var vmin = binding.edtRandMin.text.toString().toIntOrNull() ?: 30
        var vmax = binding.edtRandMax.text.toString().toIntOrNull() ?: 200
        vmin = max(0, vmin)
        vmax = min(65535, vmax)
        if (vmin > vmax) {
            val t = vmin; vmin = vmax; vmax = t
        }

        val tsp: Int = if (lastTsp != null && random.nextFloat() < 0.8f) {
            val base = lastTsp!!
            val delta = vmax * 0.1f
            (base + random.nextFloat() * 2 * delta - delta).toInt().coerceIn(vmin, vmax)
        } else {
            vmin + random.nextInt(vmax - vmin + 1)
        }

        val weather = random.nextInt(3)
        val pm10: Int
        val pm25: Int
        when (weather) {
            0 -> {
                pm10 = (tsp * (0.7f + random.nextFloat() * 0.2f)).toInt()
                pm25 = (pm10 * (0.1f + random.nextFloat() * 0.2f)).toInt()
            }
            1 -> {
                pm10 = (tsp * (0.7f + random.nextFloat() * 0.25f)).toInt()
                pm25 = (pm10 * (0.6f + random.nextFloat() * 0.25f)).toInt()
            }
            else -> {
                pm10 = (tsp * (0.6f + random.nextFloat() * 0.2f)).toInt()
                pm25 = (pm10 * (0.4f + random.nextFloat() * 0.2f)).toInt()
            }
        }
        val pm10Final = min(pm10, tsp)
        val pm25Final = min(pm25, pm10Final)

        lastTsp = tsp; lastPm10 = pm10Final; lastPm25 = pm25Final

        setValues(pm25Final.toString(), pm10Final.toString(), tsp.toString())
        updateChart(tsp.toFloat(), pm10Final.toFloat(), pm25Final.toFloat())
        updateRawHex()
    }

    /** 构造 36 字节 payload（对应 main.py update_raw_hex） */
    private fun buildPayload(): ByteArray {
        val payload = ByteArray(36)
        // bytearray([0]*12 + [0x02] + [0xFF]*19 + [0x00,0x01,0x00,0x04])
        payload[12] = 0x02
        for (i in 13 until 32) payload[i] = 0xFF.toByte()
        payload[32] = 0x00; payload[33] = 0x01; payload[34] = 0x00; payload[35] = 0x04

        val pm25 = safeInt(binding.edtPm25.text.toString())
        val pm10 = safeInt(binding.edtPm10.text.toString())
        val tsp = safeInt(binding.edtTsp.text.toString())

        payload[2] = (pm25 shr 8).toByte(); payload[3] = (pm25 and 0xFF).toByte()
        payload[6] = (pm10 shr 8).toByte(); payload[7] = (pm10 and 0xFF).toByte()
        payload[10] = (tsp shr 8).toByte(); payload[11] = (tsp and 0xFF).toByte()
        return payload
    }

    private fun updateRawHex() {
        binding.txtPayload.text = Protocol.toHex(buildPayload())
    }

    /** 构造完整应答帧：3A 01 04 2A + payload(36) + CRC16（对应 main.py build_sim_frame） */
    private fun buildSimFrame(): ByteArray? {
        val payload = buildPayload()
        if (payload.size != 36) return null
        val simData = byteArrayOf(0x3A, 0x01, 0x04, 0x2A) + payload
        val crc = Protocol.crc16Modbus(simData)
        return simData + byteArrayOf((crc and 0xFF).toByte(), ((crc shr 8) and 0xFF).toByte())
    }

    private fun safeInt(s: String): Int {
        val v = s.toIntOrNull() ?: 0
        return v.coerceIn(0, 65535)
    }

    // ==================== 接收处理（对应 main.py poll_rx / on_frame） ====================

    private fun processRx(data: ByteArray) {
        // 累积原始字节，100ms 后合并输出 RX 日志
        for (b in data) rxRawBuffer.add(b)
        scheduleRxFlush()

        val frames = fb.feed(data)
        for (f in frames) onFrame(f)
    }

    private fun scheduleRxFlush() {
        if (rxFlushRunnable != null) return
        rxFlushRunnable = Runnable {
            rxFlushRunnable = null
            if (rxRawBuffer.isNotEmpty()) {
                log("📥 RX ← ${Protocol.toHex(rxRawBuffer.toByteArray())}")
                rxRawBuffer.clear()
            }
        }
        handler.postDelayed(rxFlushRunnable!!, 100)
    }

    private fun onFrame(frame: ByteArray) {
        if (modeIsSimulate()) {
            // 从站模式：匹配指令自动应答
            if (binding.chkAutoReply.isChecked && serial.isOpen()) {
                val expected = parseCmd()
                if (expected != null && frame.contentEquals(expected)) {
                    flushRxNow()
                    if (binding.chkAutoRandom.isChecked) generateRandom()
                    val reply = buildSimFrame()
                    if (reply != null) {
                        serial.send(reply)
                        log("📤 TX(TSP应答) → ${Protocol.toHex(reply)}")
                    }
                }
            }
        } else {
            // 主站模式：解析真实设备帧
            if (frame.size >= 2 && (frame[0].toInt() and 0xFF) == Protocol.FRAME_HEADER &&
                frame.size >= 42 && (frame[2].toInt() and 0xFF) == Protocol.CMD_READ
            ) {
                flushRxNow()
                val payload = frame.copyOfRange(4, 40)
                binding.txtPayload.text = Protocol.toHex(payload)

                val pm25 = ((payload[2].toInt() and 0xFF) shl 8) or (payload[3].toInt() and 0xFF)
                val pm10 = ((payload[6].toInt() and 0xFF) shl 8) or (payload[7].toInt() and 0xFF)
                val tsp = ((payload[10].toInt() and 0xFF) shl 8) or (payload[11].toInt() and 0xFF)

                setValues(pm25.toString(), pm10.toString(), tsp.toString())
                updateChart(tsp.toFloat(), pm10.toFloat(), pm25.toFloat())
                log("✅ 解析成功 → TSP:$tsp, PM10:$pm10, PM2.5:$pm25")
            }
        }
    }

    private fun flushRxNow() {
        rxFlushRunnable?.let { handler.removeCallbacks(it) }
        rxFlushRunnable = null
        if (rxRawBuffer.isNotEmpty()) {
            log("📥 RX ← ${Protocol.toHex(rxRawBuffer.toByteArray())}")
            rxRawBuffer.clear()
        }
    }

    // ==================== 图表与日志 ====================

    private fun clearChart() {
        binding.chartView.clear()
        lastTsp = null; lastPm10 = null; lastPm25 = null
        updateRawHex()
    }

    private fun updateChart(tsp: Float, pm10: Float, pm25: Float) {
        binding.chartView.addPoint(timeFmt.format(Date()), tsp, pm10, pm25)
    }

    private fun log(msg: String) {
        val line = "[${timeFmt.format(Date())}] $msg"
        val current = binding.txtLog.text
        var sb = StringBuilder(current)
        if (sb.isNotEmpty()) sb.append('\n')
        sb.append(line)
        // 限制行数，避免内存膨胀
        val lines = sb.toString().split('\n')
        if (lines.size > MAX_LOG_LINES) {
            sb = StringBuilder(lines.takeLast(MAX_LOG_LINES).joinToString("\n"))
        }
        binding.txtLog.text = sb.toString()
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    // ==================== 生命周期 ====================

    override fun onResume() {
        super.onResume()
        val filter = IntentFilter().apply {
            addAction(USB_PERMISSION)
            addAction(UsbManager.ACTION_USB_DEVICE_DETACHED)
        }
        registerReceiver(usbReceiver, filter)
        refreshDevices()
    }

    override fun onPause() {
        unregisterReceiver(usbReceiver)
        super.onPause()
    }

    override fun onDestroy() {
        stopLoop()
        rxFlushRunnable?.let { handler.removeCallbacks(it) }
        serial.close()
        super.onDestroy()
    }
}
