package com.tsp.tester.serial

import android.content.Context
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import com.hoho.android.usbserial.driver.UsbSerialDriver
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import java.io.IOException

/**
 * 串口读写管理 —— 移植自 serial_worker.py。
 * Android 端通过 USB OTG 连接 USB 转串口芯片（CH340 / CP210x / FTDI / PL2303 等），
 * 底层驱动由 usb-serial-for-android 提供。
 */
class SerialManager(private val context: Context) {

    companion object {
        const val DEFAULT_TIMEOUT_MS = 1000
        const val READ_CHUNK = 256
    }

    private val usbManager: UsbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager

    var port: UsbSerialPort? = null
        private set
    var onData: ((ByteArray) -> Unit)? = null
    var onError: ((String) -> Unit)? = null

    private var readThread: Thread? = null
    private var running = false
    @Volatile private var lastDevice: UsbDevice? = null

    fun isOpen(): Boolean = port != null

    /** 探测当前已连接的 USB 串口设备列表 */
    fun listDevices(): List<UsbDevice> =
        usbManager.deviceList.values
            .filter { UsbSerialProber.getDefaultProber().probeDevice(it) != null }
            .toList()

    fun hasPermission(device: UsbDevice): Boolean =
        usbManager.hasPermission(device)

    /** 列出当前连接的全部 USB 设备（含未被识别为串口的），用于诊断 */
    fun listAllUsbDevices(): List<UsbDevice> = usbManager.deviceList.values.toList()

    fun requestPermission(device: UsbDevice, pendingIntent: android.app.PendingIntent) {
        usbManager.requestPermission(device, pendingIntent)
    }

    /** 打开串口并启动读线程（对应 SerialWorker.open + _read_loop） */
    fun open(device: UsbDevice, baud: Int) {
        close()
        val driver: UsbSerialDriver =
            UsbSerialProber.getDefaultProber().probeDevice(device)
                ?: throw IOException("不支持的 USB 串口设备: ${device.productName ?: device.deviceName}")
        val p: UsbSerialPort = driver.ports[0]
        val connection = usbManager.openDevice(device)
            ?: throw IOException("无法打开 USB 设备，请检查 OTG 连接")
        p.open(connection)
        p.setParameters(baud, UsbSerialPort.DATABITS_8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
        port = p
        lastDevice = device
        running = true
        readThread = Thread({ readLoop(p) }, "tsp-serial-read").apply { start() }
    }

    private fun readLoop(p: UsbSerialPort) {
        val buffer = ByteArray(READ_CHUNK)
        while (running) {
            try {
                val n = p.read(buffer, DEFAULT_TIMEOUT_MS)
                if (n > 0) {
                    onData?.invoke(buffer.copyOf(n))
                }
            } catch (e: Exception) {
                if (running) {
                    onError?.invoke(e.message ?: "串口读取错误")
                    if (e is IOException) break
                }
            }
        }
    }

    /** 发送数据（对应 SerialWorker.send） */
    fun send(data: ByteArray): Boolean {
        val p = port ?: return false
        return try {
            p.write(data, DEFAULT_TIMEOUT_MS)
            true
        } catch (e: Exception) {
            onError?.invoke(e.message ?: "串口发送错误")
            false
        }
    }

    /** 关闭串口（对应 SerialWorker.close） */
    fun close() {
        running = false
        readThread?.let {
            try {
                it.interrupt()
            } catch (_: Exception) {
            }
        }
        readThread = null
        val p = port
        port = null
        if (p != null) {
            try {
                p.close()
            } catch (_: Exception) {
            }
        }
        lastDevice = null
    }

    fun currentDevice(): UsbDevice? = lastDevice
}
