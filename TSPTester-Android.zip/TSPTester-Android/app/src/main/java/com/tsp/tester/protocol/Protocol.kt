package com.tsp.tester.protocol

/**
 * 协议常量与工具 —— 移植自 protocol.py / config.py
 */
object Protocol {
    const val FRAME_HEADER: Int = 0x3A
    const val DEVICE_ADDR: Int = 0x01
    const val CMD_READ: Int = 0x04

    /** 帧结构: header(1) + addr(1) + cmd(1) + len(1) + payload(n) + tail(2) */
    const val FRAME_FIXED_HEADER_LEN = 4
    const val FRAME_TAIL_LEN = 2
    const val MAX_FRAME_LEN = 512

    // 发送指令（主站请求读，数据区 18 个 FF 为占位）
    val SEND_FRAME: ByteArray = byteArrayOf(0x3A, 0x01, 0x04, 0x18) +
        ByteArray(18) { 0xFF.toByte() } + byteArrayOf(0xB4.toByte(), 0x00)

    // 数据组定位（含帧头的字节索引，与 config.DATA_GROUPS 一致）
    data class DataGroup(val name: String, val start: Int, val end: Int)
    val DATA_GROUPS = listOf(
        DataGroup("TSP", 15, 17),
        DataGroup("PM10", 36, 38),
        DataGroup("PM2.5", 38, 40),
    )

    val INVALID_VALUES = setOf(0x0000, 0xFFFF)

    fun toHex(data: ByteArray): String =
        data.joinToString(" ") { "%02X".format(it.toInt() and 0xFF) }

    /** CRC16-Modbus，与 protocol.py crc16_modbus 一致 */
    fun crc16Modbus(data: ByteArray): Int {
        var crc = 0xFFFF
        for (b in data) {
            crc = crc xor (b.toInt() and 0xFF)
            repeat(8) {
                crc = if (crc and 1 == 1) (crc shr 1) xor 0xA001 else crc shr 1
            }
        }
        return crc
    }
}

/**
 * 粘包/半包处理：从串口流中切出完整 0x3A 帧 —— 移植自 protocol.py FrameBuffer
 */
class FrameBuffer {
    private val buf = ArrayList<Byte>()

    fun feed(data: ByteArray): List<ByteArray> {
        for (b in data) buf.add(b)
        val frames = mutableListOf<ByteArray>()
        while (true) {
            val idx = buf.indexOfFirst { it.toInt() and 0xFF == Protocol.FRAME_HEADER }
            if (idx < 0) {
                buf.clear()
                break
            }
            if (idx > 0) {
                repeat(idx) { buf.removeAt(0) }
            }
            if (buf.size < Protocol.FRAME_FIXED_HEADER_LEN) break
            val frameLen = buf[3].toInt() and 0xFF
            if (frameLen < Protocol.FRAME_FIXED_HEADER_LEN + Protocol.FRAME_TAIL_LEN ||
                frameLen > Protocol.MAX_FRAME_LEN
            ) {
                buf.removeAt(0) // 长度异常，丢弃该头继续找
                continue
            }
            if (buf.size < frameLen) break
            val frame = ByteArray(frameLen) { buf[it] }
            repeat(frameLen) { buf.removeAt(0) }
            frames.add(frame)
        }
        return frames
    }

    fun clear() {
        buf.clear()
    }
}
