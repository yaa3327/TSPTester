import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import queue
import time
import serial.tools.list_ports
import re
import random
from datetime import datetime
from collections import deque

import numpy as np
from scipy.interpolate import make_interp_spline

import matplotlib
matplotlib.use("TkAgg")
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import matplotlib.pyplot as plt

import config
from serial_worker import SerialWorker
from protocol import to_hex, crc16_modbus, FrameBuffer

plt.rcParams['font.sans-serif'] = ['Microsoft YaHei', 'SimHei']
plt.rcParams['axes.unicode_minus'] = False

class App:
    def __init__(self, root):
        self.root = root
        self.root.title("TSP 监测盒调试神器 v7.9")
        self.root.geometry("1300x850")
        
        try:
            self.root.iconbitmap("icon.ico")
        except Exception:
            pass
            
        self.worker = SerialWorker()
        self.fb = FrameBuffer()
        
        self.last_tsp = None
        self.last_pm10 = None
        self.last_pm25 = None

        self.max_points = 100
        self.history_time = deque(maxlen=self.max_points)
        self.history_tsp = deque(maxlen=self.max_points)
        self.history_pm10 = deque(maxlen=self.max_points)
        self.history_pm25 = deque(maxlen=self.max_points)

        self.is_reading = False
        self.read_job = None
        
        self.read_cmd_hex = "3A 01 04 18 FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF FF B4 00"

        self.rx_raw_buffer = bytearray()
        self.rx_flush_timer = None

        self._build_ui()
        self.refresh_ports()
        self.root.after(20, self.poll_rx)

    def _build_ui(self):
        # === 顶部：串口 ===
        top = ttk.Frame(self.root, padding=6)
        top.pack(fill=tk.X)
        ttk.Label(top, text="串口:").pack(side=tk.LEFT)
        self.port_var = tk.StringVar()
        self.port_cb = ttk.Combobox(top, textvariable=self.port_var, width=10, state="readonly")
        self.port_cb.pack(side=tk.LEFT, padx=4)
        ttk.Button(top, text="刷新", command=self.refresh_ports).pack(side=tk.LEFT)
        
        ttk.Label(top, text="波特率:").pack(side=tk.LEFT, padx=(10, 0))
        self.baud_var = tk.StringVar(value="19200")
        ttk.Combobox(top, textvariable=self.baud_var, width=8, state="readonly",
                     values=["9600", "19200", "38400", "57600", "115200"]).pack(side=tk.LEFT, padx=4)
                     
        self.serial_btn = ttk.Button(top, text="打开串口", command=self.toggle_serial)
        self.serial_btn.pack(side=tk.LEFT, padx=8)
        self.status_var = tk.StringVar(value="未连接")
        ttk.Label(top, textvariable=self.status_var, foreground="gray").pack(side=tk.LEFT, padx=8)

        # === 模式切换 ===
        mode_frame = ttk.Frame(self.root, padding=6)
        mode_frame.pack(fill=tk.X)
        
        self.mode_var = tk.StringVar(value="read")
        ttk.Radiobutton(mode_frame, text="📡 主站模式 (读取真实设备)", variable=self.mode_var, 
                        value="read", command=self.on_mode_change).pack(side=tk.LEFT, padx=10)
        ttk.Radiobutton(mode_frame, text="🤖 从站模式 (模拟设备)", variable=self.mode_var, 
                        value="simulate", command=self.on_mode_change).pack(side=tk.LEFT, padx=10)

        # === 动态控制区 ===
        self.ctrl_container = ttk.Frame(self.root)
        self.ctrl_container.pack(fill=tk.X, padx=6, pady=2)

        # 读取面板 (主站模式)
        self.read_frame = ttk.LabelFrame(self.ctrl_container, text="主站读取控制", padding=10)
        
        ttk.Label(self.read_frame, text="读取指令:").pack(side=tk.LEFT)
        self.read_cmd_var = tk.StringVar(value=self.read_cmd_hex)
        self.cmd_entry = ttk.Entry(self.read_frame, textvariable=self.read_cmd_var, width=65, state="readonly")
        self.cmd_entry.pack(side=tk.LEFT, padx=5)
        
        ttk.Button(self.read_frame, text="📤 发送一次测试", command=self.send_single_read).pack(side=tk.LEFT, padx=5)

        ttk.Label(self.read_frame, text="周期(ms):").pack(side=tk.LEFT, padx=(15, 0))
        self.read_interval = tk.StringVar(value="1000")
        ttk.Entry(self.read_frame, textvariable=self.read_interval, width=6).pack(side=tk.LEFT, padx=2)
        
        self.read_btn = ttk.Button(self.read_frame, text="▶ 开始循环读取", command=self.toggle_reading)
        self.read_btn.pack(side=tk.LEFT, padx=10)

        # 模拟面板 (从站模式)
        self.sim_frame = ttk.LabelFrame(self.ctrl_container, text="从站模拟控制", padding=10)
        self.auto_reply_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(self.sim_frame, text="启用自动应答 (需完全匹配指令)", variable=self.auto_reply_var).pack(side=tk.LEFT, padx=(0, 10))
        
        self.auto_random_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(self.sim_frame, text="每次随机", variable=self.auto_random_var, command=self.on_random_toggle).pack(side=tk.LEFT, padx=(0, 10))

        ttk.Label(self.sim_frame, text="TSP范围:").pack(side=tk.LEFT, padx=(10, 0))
        self.rand_min = tk.StringVar(value="30")
        ttk.Entry(self.sim_frame, textvariable=self.rand_min, width=5).pack(side=tk.LEFT, padx=2)
        ttk.Label(self.sim_frame, text="~").pack(side=tk.LEFT)
        self.rand_max = tk.StringVar(value="200")
        ttk.Entry(self.sim_frame, textvariable=self.rand_max, width=5).pack(side=tk.LEFT, padx=2)
        
        ttk.Button(self.sim_frame, text="🎲 立即随机一次", command=self.generate_random).pack(side=tk.LEFT, padx=15)

        # === 数据显示区 ===
        data_frame = ttk.Frame(self.root, padding=6)
        data_frame.pack(fill=tk.X, padx=6)

        self.val_pm25 = tk.StringVar(value="0")
        self.val_pm10 = tk.StringVar(value="0")
        self.val_tsp = tk.StringVar(value="0")

        custom_font = ("Consolas", 14, "bold")

        ttk.Label(data_frame, text="PM2.5:").pack(side=tk.LEFT, padx=(10,0))
        self.entry_pm25 = ttk.Entry(data_frame, textvariable=self.val_pm25, width=8, font=custom_font, foreground="#1890FF", state="readonly")
        self.entry_pm25.pack(side=tk.LEFT, padx=2)
        
        ttk.Label(data_frame, text="PM10:").pack(side=tk.LEFT, padx=(20,0))
        self.entry_pm10 = ttk.Entry(data_frame, textvariable=self.val_pm10, width=8, font=custom_font, foreground="#FFA940", state="readonly")
        self.entry_pm10.pack(side=tk.LEFT, padx=2)

        ttk.Label(data_frame, text="TSP:").pack(side=tk.LEFT, padx=(20,0))
        self.entry_tsp = ttk.Entry(data_frame, textvariable=self.val_tsp, width=8, font=custom_font, foreground="#FF4D4F", state="readonly")
        self.entry_tsp.pack(side=tk.LEFT, padx=2)

        self.val_pm25.trace_add("write", self.on_data_changed)
        self.val_pm10.trace_add("write", self.on_data_changed)
        self.val_tsp.trace_add("write", self.on_data_changed)

        # === 图表与日志 ===
        paned = ttk.PanedWindow(self.root, orient=tk.VERTICAL)
        paned.pack(fill=tk.BOTH, expand=True, padx=6, pady=4)

        chart_frame = ttk.LabelFrame(paned, text="📈 历史数据趋势图")
        paned.add(chart_frame, weight=3)

        self.fig = Figure(figsize=(5, 2), dpi=100)
        self.ax = self.fig.add_subplot(111)
        self.fig.subplots_adjust(left=0.06, right=0.98, top=0.88, bottom=0.15)
        self.ax.grid(True, linestyle=':', color='#CCCCCC', alpha=0.6)
        self.ax.spines['top'].set_visible(False)
        self.ax.spines['right'].set_visible(False)
        self.ax.spines['left'].set_color('#888888')
        self.ax.spines['bottom'].set_color('#888888')
        self.ax.tick_params(colors='#555555')
        
        self.canvas = FigureCanvasTkAgg(self.fig, master=chart_frame)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        self.line_tsp, = self.ax.plot([], [], label='TSP', color='#FF4D4F', linewidth=1.2, marker=',', alpha=0.9)
        self.line_pm10, = self.ax.plot([], [], label='PM10', color='#FFA940', linewidth=1.2, marker=',', alpha=0.9)
        self.line_pm25, = self.ax.plot([], [], label='PM2.5', color='#1890FF', linewidth=1.2, marker=',', alpha=0.9)
        self.ax.legend(loc='upper left', fontsize=9, frameon=False)

        self.annot = self.ax.annotate("", xy=(0,0), xytext=(15,15), textcoords="offset points",
                                      bbox=dict(boxstyle="round,pad=0.5", fc="#FFFFFF", ec="#CCCCCC", alpha=0.95),
                                      arrowprops=dict(arrowstyle="->", color="#555555", connectionstyle="arc3,rad=0.1"))
        self.annot.set_visible(False)
        self.canvas.mpl_connect("motion_notify_event", self.on_plot_hover)

        bottom_frame = ttk.Frame(paned)
        paned.add(bottom_frame, weight=1)

        # 👉 自定义日志区头部，实现“文字”和“按钮”同行且不浪费空间
        log_container = ttk.Frame(bottom_frame)
        log_container.pack(fill=tk.BOTH, expand=True)

        log_header = ttk.Frame(log_container)
        log_header.pack(fill=tk.X)
        ttk.Label(log_header, text="通信日志", font=("Microsoft YaHei", 9)).pack(side=tk.LEFT, padx=2, pady=2)
        ttk.Button(log_header, text="🗑️ 清空", command=self.clear_log).pack(side=tk.RIGHT, padx=2, pady=2)

        # 下侧用 LabelFrame(text="") 来提供原有的边框视觉效果
        log_area = ttk.LabelFrame(log_container, text="")
        log_area.pack(fill=tk.BOTH, expand=True)
        
        self.log_text = scrolledtext.ScrolledText(log_area, wrap=tk.WORD, height=8, font=("Consolas", 10))
        self.log_text.pack(fill=tk.BOTH, expand=True)
        self.log_text.configure(state=tk.DISABLED)
        
        adv_frame = ttk.LabelFrame(self.root, text="⚙️ 当前 TSP 报文数据区 (36字节，不含帧头与校验)", padding=4)
        adv_frame.pack(fill=tk.X, padx=6, pady=(0, 4))
        self.raw_hex_var = tk.StringVar()
        self.raw_entry = ttk.Entry(adv_frame, textvariable=self.raw_hex_var, font=("Consolas", 10), state="readonly")
        self.raw_entry.pack(fill=tk.X)

        self.update_raw_hex()
        self.on_mode_change()
        self.on_random_toggle()

    def clear_log(self):
        self.log_text.configure(state=tk.NORMAL)
        self.log_text.delete("1.0", tk.END)
        self.log_text.configure(state=tk.DISABLED)

    def send_single_read(self):
        if not self.worker.is_open():
            messagebox.showwarning("提示", "请先打开串口")
            return
        cmd_hex = re.sub(r'[^0-9a-fA-F]', '', self.read_cmd_var.get())
        try:
            cmd_bytes = bytes.fromhex(cmd_hex)
            self.worker.send(cmd_bytes)
            self.log(f"📡 TX(主站单次) → {to_hex(cmd_bytes)}")
        except ValueError:
            self.log("❌ 读取指令 HEX 格式错误！")

    def on_random_toggle(self):
        if self.mode_var.get() == "simulate":
            if self.auto_random_var.get():
                self.entry_pm25.config(state="readonly")
                self.entry_pm10.config(state="readonly")
                self.entry_tsp.config(state="readonly")
            else:
                self.entry_pm25.config(state="normal")
                self.entry_pm10.config(state="normal")
                self.entry_tsp.config(state="normal")
        else:
            self.entry_pm25.config(state="readonly")
            self.entry_pm10.config(state="readonly")
            self.entry_tsp.config(state="readonly")

    def clear_chart(self):
        self.history_time.clear()
        self.history_tsp.clear()
        self.history_pm10.clear()
        self.history_pm25.clear()
        self.line_tsp.set_data([], [])
        self.line_pm10.set_data([], [])
        self.line_pm25.set_data([], [])
        self.ax.set_xlim(0, 10)
        self.ax.set_ylim(0, 100)
        self.ax.set_xticks([])
        self.ax.set_xticklabels([])
        self.canvas.draw_idle()
        self.val_pm25.set("0")
        self.val_pm10.set("0")
        self.val_tsp.set("0")
        self.update_raw_hex()

    def on_mode_change(self):
        self.clear_chart()
        if self.mode_var.get() == "read":
            self.sim_frame.pack_forget()
            self.read_frame.pack(fill=tk.X)
            self.auto_reply_var.set(False)
            self.entry_pm25.config(state="readonly")
            self.entry_pm10.config(state="readonly")
            self.entry_tsp.config(state="readonly")
            self.cmd_entry.config(state="readonly")
            self.log("--- 已切换至主站模式 (读取指令已锁定) ---")
        else:
            self.read_frame.pack_forget()
            self.sim_frame.pack(fill=tk.X)
            if self.is_reading: self.toggle_reading()
            self.on_random_toggle()
            self.cmd_entry.config(state="normal")
            self.log("--- 已切换至从站模式 (需完全匹配指令才回复) ---")

    def toggle_reading(self):
        if not self.worker.is_open():
            messagebox.showwarning("提示", "请先打开串口")
            return
        if self.is_reading:
            self.is_reading = False
            self.read_btn.config(text="▶ 开始循环读取")
            if self.read_job:
                self.root.after_cancel(self.read_job)
                self.read_job = None
            self.log("⏹ 停止循环读取")
        else:
            self.is_reading = True
            self.read_btn.config(text="⏸ 停止循环读取")
            self.log("▶ 开始循环读取")
            self.do_read_loop()

    def do_read_loop(self):
        if not self.is_reading: return
        if not self.worker.is_open():
            self.toggle_reading()
            return
            
        cmd_hex = re.sub(r'[^0-9a-fA-F]', '', self.read_cmd_var.get())
        try:
            cmd_bytes = bytes.fromhex(cmd_hex)
            self.worker.send(cmd_bytes)
            self.log(f"📡 TX(主站循环) → {to_hex(cmd_bytes)}")
        except ValueError:
            self.log("❌ 读取指令 HEX 格式错误，停止循环")
            self.toggle_reading()
            return

        try: interval = int(self.read_interval.get())
        except ValueError: interval = 1000
        self.read_job = self.root.after(interval, self.do_read_loop)

    def on_plot_hover(self, event):
        vis = self.annot.get_visible()
        if event.inaxes == self.ax:
            for line in [self.line_tsp, self.line_pm10, self.line_pm25]:
                cont, ind = line.contains(event)
                if cont:
                    idx = ind["ind"][0]
                    x, y = line.get_data()
                    real_idx = int(round(x[idx]))
                    if real_idx >= len(self.history_time): real_idx = len(self.history_time) - 1
                    if real_idx < 0: real_idx = 0
                    time_str = self.history_time[real_idx]
                    label_name = line.get_label()
                    if label_name == 'TSP': real_val = self.history_tsp[real_idx]
                    elif label_name == 'PM10': real_val = self.history_pm10[real_idx]
                    else: real_val = self.history_pm25[real_idx]
                    text = f"{time_str}\n{label_name}: {real_val}"
                    self.annot.xy = (x[idx], y[idx])
                    self.annot.set_text(text)
                    self.annot.set_visible(True)
                    self.canvas.draw_idle()
                    return
            if vis:
                self.annot.set_visible(False)
                self.canvas.draw_idle()

    def on_data_changed(self, *args):
        if self.mode_var.get() == "simulate" and not self.auto_random_var.get():
            self.update_raw_hex()

    def update_chart(self, tsp, pm10, pm25):
        now_str = datetime.now().strftime("%H:%M:%S")
        self.history_time.append(now_str)
        self.history_tsp.append(tsp)
        self.history_pm10.append(pm10)
        self.history_pm25.append(pm25)

        x_data = np.arange(len(self.history_time))
        y_tsp = np.array(self.history_tsp)
        y_pm10 = np.array(self.history_pm10)
        y_pm25 = np.array(self.history_pm25)

        if len(x_data) >= 4:
            x_smooth = np.linspace(x_data.min(), x_data.max(), 300)
            self.line_tsp.set_data(x_smooth, make_interp_spline(x_data, y_tsp, k=3)(x_smooth))
            self.line_pm10.set_data(x_smooth, make_interp_spline(x_data, y_pm10, k=3)(x_smooth))
            self.line_pm25.set_data(x_smooth, make_interp_spline(x_data, y_pm25, k=3)(x_smooth))
        else:
            self.line_tsp.set_data(x_data, y_tsp)
            self.line_pm10.set_data(x_data, y_pm10)
            self.line_pm25.set_data(x_data, y_pm25)

        self.ax.set_xlim(0, max(10, len(x_data) - 1))
        self.ax.set_ylim(0, max(max(self.history_tsp, default=10), 10) * 1.2)
        step = max(1, len(x_data) // 10)
        self.ax.set_xticks(x_data[::step])
        self.ax.set_xticklabels([self.history_time[i] for i in x_data[::step]], rotation=0, fontsize=9)
        self.canvas.draw()

    def generate_random(self):
        try:
            vmin = max(0, int(self.rand_min.get()))
            vmax = min(65535, int(self.rand_max.get()))
            if vmin > vmax: vmin, vmax = vmax, vmin
        except ValueError: vmin, vmax = 10, 500

        if self.last_tsp is not None and random.random() < 0.8:
            tsp = int(self.last_tsp + random.uniform(-vmax*0.1, vmax*0.1))
            tsp = max(vmin, min(vmax, tsp))
        else:
            tsp = random.randint(vmin, vmax)

        weather_mode = random.choice([0, 1, 2])
        if weather_mode == 0:
            pm10 = int(tsp * random.uniform(0.7, 0.9))
            pm25 = int(pm10 * random.uniform(0.1, 0.3))
        elif weather_mode == 1:
            pm10 = int(tsp * random.uniform(0.7, 0.95))
            pm25 = int(pm10 * random.uniform(0.6, 0.85))
        else:
            pm10 = int(tsp * random.uniform(0.6, 0.8))
            pm25 = int(pm10 * random.uniform(0.4, 0.6))

        pm10 = min(pm10, tsp)
        pm25 = min(pm25, pm10)

        self.last_tsp, self.last_pm10, self.last_pm25 = tsp, pm10, pm25

        self.val_pm25.set(str(pm25))
        self.val_pm10.set(str(pm10))
        self.val_tsp.set(str(tsp))
        self.update_chart(tsp, pm10, pm25)
        self.update_raw_hex()

    def safe_int(self, val_str):
        try:
            return max(0, min(65535, int(val_str)))
        except ValueError: 
            return 0

    def update_raw_hex(self):
        pm25 = self.safe_int(self.val_pm25.get())
        pm10 = self.safe_int(self.val_pm10.get())
        tsp = self.safe_int(self.val_tsp.get())

        payload = bytearray([0x00] * 12 + [0x02] + [0xFF] * 19 + [0x00, 0x01, 0x00, 0x04])
        payload[2:4] = pm25.to_bytes(2, 'big')       
        payload[6:8] = pm10.to_bytes(2, 'big')       
        payload[10:12] = tsp.to_bytes(2, 'big')      

        hex_str = " ".join(f"{b:02X}" for b in payload)
        self.raw_hex_var.set(hex_str)

    def build_sim_frame(self):
        hex_str = re.sub(r'[^0-9a-fA-F]', '', self.raw_hex_var.get())
        payload = bytes.fromhex(hex_str)
        if len(payload) != 36: return None
        sim_data = bytearray([0x3A, 0x01, 0x04, 0x2A])
        sim_data.extend(payload)
        crc = crc16_modbus(sim_data)
        sim_data.append(crc & 0xFF)
        sim_data.append((crc >> 8) & 0xFF)
        return bytes(sim_data)

    def refresh_ports(self):
        ports = [p.device for p in serial.tools.list_ports.comports()]
        self.port_cb["values"] = ports
        if ports and not self.port_var.get(): self.port_var.set(ports[0])

    def toggle_serial(self):
        if self.worker.is_open():
            if self.is_reading: self.toggle_reading()
            self.worker.close()
            self.serial_btn.configure(text="打开串口")
            self.status_var.set("未连接")
            self.log("❌ 串口已关闭")
        else:
            try:
                self.worker.open(self.port_var.get(), int(self.baud_var.get()))
                self.serial_btn.configure(text="关闭串口")
                self.status_var.set("已连接")
                self.log(f"✅ 串口已打开: {self.port_var.get()} @ {self.baud_var.get()}")
            except Exception as e:
                messagebox.showerror("串口错误", str(e))

    def log(self, msg):
        ts = time.strftime("%H:%M:%S")
        self.log_text.configure(state=tk.NORMAL)
        self.log_text.insert(tk.END, f"[{ts}] {msg}\n")
        self.log_text.see(tk.END)
        self.log_text.configure(state=tk.DISABLED)

    def flush_rx_log(self):
        if self.rx_raw_buffer:
            self.log(f"📥 RX ← {to_hex(self.rx_raw_buffer)}")
            self.rx_raw_buffer.clear()
        if self.rx_flush_timer:
            self.root.after_cancel(self.rx_flush_timer)
            self.rx_flush_timer = None

    def poll_rx(self):
        try:
            while True:
                item = self.worker.rx_queue.get_nowait()
                if isinstance(item, tuple) and item[0] == "error": continue
                
                self.rx_raw_buffer.extend(item)
                
                if not self.rx_flush_timer:
                    self.rx_flush_timer = self.root.after(100, self.flush_rx_log)

                frames = self.fb.feed(item)
                for f in frames:
                    self.on_frame(f)
        except queue.Empty:
            pass
        self.root.after(20, self.poll_rx)

    def on_frame(self, frame: bytes):
        if self.mode_var.get() == "read":
            # 主站解析
            if frame[0] == 0x3A:
                if len(frame) >= 42:
                    if frame[2] == 0x04:
                        self.flush_rx_log()

                        payload = frame[4:40]
                        payload_hex = " ".join(f"{b:02X}" for b in payload)
                        self.raw_hex_var.set(payload_hex)

                        pm25 = int.from_bytes(payload[2:4], 'big')
                        pm10 = int.from_bytes(payload[6:8], 'big')
                        tsp = int.from_bytes(payload[10:12], 'big')
                        
                        self.val_pm25.set(str(pm25))
                        self.val_pm10.set(str(pm10))
                        self.val_tsp.set(str(tsp))
                        self.update_chart(tsp, pm10, pm25)
                        self.log(f"✅ 解析成功 → TSP:{tsp}, PM10:{pm10}, PM2.5:{pm25}")

        elif self.mode_var.get() == "simulate":
            # 从站模拟
            if self.auto_reply_var.get() and self.worker.is_open():
                cmd_hex = re.sub(r'[^0-9a-fA-F]', '', self.read_cmd_var.get())
                try:
                    expected_cmd_bytes = bytes.fromhex(cmd_hex)
                except ValueError:
                    expected_cmd_bytes = b""
                
                if expected_cmd_bytes and frame == expected_cmd_bytes:
                    self.flush_rx_log()

                    if self.auto_random_var.get(): 
                        self.generate_random()
                    reply_frame = self.build_sim_frame()
                    if reply_frame:
                        self.worker.send(reply_frame)
                        self.log(f"📤 TX(TSP应答) → {to_hex(reply_frame)}")

def main():
    root = tk.Tk()
    App(root)
    root.mainloop()

if __name__ == "__main__":
    main()