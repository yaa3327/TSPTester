import threading
import queue
import serial


class SerialWorker:
    def __init__(self):
        self.ser = None
        self.rx_queue = queue.Queue()
        self._running = False
        self._thread = None
        self._lock = threading.Lock()

    def is_open(self) -> bool:
        return self.ser is not None and self.ser.is_open

    def open(self, port, baud, timeout=0.05):
        self.close()
        self.ser = serial.Serial(port, baud, timeout=timeout)
        self._running = True
        self._thread = threading.Thread(target=self._read_loop, daemon=True)
        self._thread.start()

    def _read_loop(self):
        while self._running and self.ser and self.ser.is_open:
            try:
                data = self.ser.read(256)
                if data:
                    self.rx_queue.put(data)
            except Exception as e:
                self.rx_queue.put(("error", str(e)))
                break

    def send(self, data: bytes) -> bool:
        with self._lock:
            if self.ser and self.ser.is_open:
                try:
                    self.ser.write(data)
                    return True
                except Exception as e:
                    self.rx_queue.put(("error", str(e)))
        return False

    def close(self):
        self._running = False
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=0.5)
        if self.ser:
            try:
                self.ser.close()
            except Exception:
                pass
            self.ser = None