@echo off
chcp 65001 >nul
echo ==========================================
echo  TSP ??????? - ????
echo ==========================================

echo [1/3] ????...
pip install pyserial pyinstaller
if errorlevel 1 goto fail

echo [2/3] ?????...
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist TSPTester.spec del /q TSPTester.spec

echo [3/3] ????...
pyinstaller -F -w -n TSPTester --clean main.py
if errorlevel 1 goto fail

echo.
echo ??????????dist\TSPTester.exe
pause
exit /b 0

:fail
echo.
echo ? ???????????????
pause
exit /b 1