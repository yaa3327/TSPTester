# ================= 串口默认参数 =================
DEFAULT_BAUD = 9600
DEFAULT_TIMEOUT = 0.05  # 秒

# ================= 协议常量 =================
FRAME_HEADER = 0x3A
DEVICE_ADDR = 0x01
CMD_READ = 0x04

# 发送指令（主站请求读，数据区 18 个 FF 为占位）
SEND_FRAME = bytes([0x3A, 0x01, 0x04, 0x18] + [0xFF] * 18 + [0xB4, 0x00])

# 帧结构: header(1) + addr(1) + cmd(1) + len(1) + payload(n) + tail(2)
FRAME_FIXED_HEADER_LEN = 4
FRAME_TAIL_LEN = 2

# ================= 数据组定位 =================
# 注意：这里的 start/end 是【整个接收帧】的字节索引（含帧头）
# 帧索引 0=0x3A, 1=addr, 2=cmd, 3=len, 4 起为 payload
# 下方默认值基于你之前提供的样本报文推断，如与实测不符请修改：
#   TSP   : 帧索引 15~16 → payload[11..12] = 00 02 → 0x0002
#   PM10  : 帧索引 36~37 → payload[32..33] = 00 01 → 0x0001
#   PM2.5 : 帧索引 38~39 → payload[34..35] = 00 04 → 0x0004
DATA_GROUPS = [
    ("TSP",   15, 17),
    ("PM10",  36, 38),
    ("PM2.5", 38, 40),
]

# 用于判断"全部为填充值"时把哪些值视为无效
INVALID_VALUES = (0x0000, 0xFFFF)

# ================= 接收处理 =================
MAX_FRAME_LEN = 512