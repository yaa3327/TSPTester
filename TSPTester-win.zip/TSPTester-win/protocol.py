import config


def to_hex(data: bytes) -> str:
    return " ".join(f"{b:02X}" for b in data)


def crc16_modbus(data: bytes) -> int:
    crc = 0xFFFF
    for b in data:
        crc ^= b
        for _ in range(8):
            if crc & 1:
                crc = (crc >> 1) ^ 0xA001
            else:
                crc >>= 1
    return crc


class FrameBuffer:
    """处理粘包/半包：从串口流中切出完整 0x3A 帧。"""
    def __init__(self):
        self.buf = bytearray()

    def feed(self, data: bytes):
        self.buf.extend(data)
        frames = []
        while True:
            idx = self.buf.find(config.FRAME_HEADER)
            if idx < 0:
                self.buf.clear()
                break
            if idx > 0:
                del self.buf[:idx]
            if len(self.buf) < config.FRAME_FIXED_HEADER_LEN:
                break
            frame_len = self.buf[3]
            if frame_len < config.FRAME_FIXED_HEADER_LEN + config.FRAME_TAIL_LEN \
                    or frame_len > config.MAX_FRAME_LEN:
                del self.buf[0]  # 长度异常，丢弃该头继续找
                continue
            if len(self.buf) < frame_len:
                break
            frames.append(bytes(self.buf[:frame_len]))
            del self.buf[:frame_len]
        return frames


def parse_frame(frame: bytes) -> dict:
    info = {
        "addr": None, "cmd": None, "len_field": 0,
        "payload": b"", "payload_start": config.FRAME_FIXED_HEADER_LEN,
        "tail": b"", "error": None,
    }
    if len(frame) < config.FRAME_FIXED_HEADER_LEN + config.FRAME_TAIL_LEN:
        info["error"] = "帧太短"
        return info
    info["addr"] = frame[1]
    info["cmd"] = frame[2]
    info["len_field"] = frame[3]
    if info["len_field"] != len(frame):
        info["error"] = (f"长度字段 0x{info['len_field']:02X}({info['len_field']}) "
                         f"与实际 {len(frame)} 字节不符")
    info["tail"] = frame[-config.FRAME_TAIL_LEN:]
    info["payload"] = frame[config.FRAME_FIXED_HEADER_LEN: len(frame) - config.FRAME_TAIL_LEN]
    return info


def compute_checksums(frame: bytes) -> dict:
    """对帧尾之前的字节试算多种校验，方便与帧尾 B4 00 / 80 20 对比。"""
    body = frame[:-config.FRAME_TAIL_LEN]
    s8 = sum(body) & 0xFF
    s16 = sum(body) & 0xFFFF
    x = 0
    for b in body:
        x ^= b
    crc = crc16_modbus(body)
    return {
        "sum8":        f"0x{s8:02X}",
        "sum16":       f"0x{s16:04X}",
        "xor8":        f"0x{x:02X}",
        "crc16_modbus": f"0x{crc:04X}",
        "crc16_le":    f"0x{crc & 0xFF:02X} 0x{(crc >> 8) & 0xFF:02X}",
    }


def extract_groups(frame: bytes):
    result = []
    for name, start, end in config.DATA_GROUPS:
        if end <= len(frame):
            val = int.from_bytes(frame[start:end], "big")
            result.append((name, (start, end), val))
        else:
            result.append((name, (start, end), None))
    return result


def diagnose(frame: bytes, info: dict, groups: list):
    if info.get("error"):
        return "协议异常", info["error"]
    vals = [v for _, _, v in groups if v is not None]
    if not vals:
        return "数据异常", "无法定位三组数据（请检查 config.DATA_GROUPS）"
    if all(v in config.INVALID_VALUES for v in vals):
        return "数据异常", "三组数据全部为填充值，疑似传感器未接入或失效"
    detail = ", ".join(f"{n}={v}" for n, _, v in groups if v is not None)
    return "通过", f"三组数据：{detail}"